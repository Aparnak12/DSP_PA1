###############################################
#
# Author: Aniruddha Gokhale
# Vanderbilt University
#
# Purpose: Subscriber Middleware with Broker Support
#
# Created: Spring 2023
#
###############################################

import zmq
import logging
from CS6381_MW import discovery_pb2

class SubscriberMW:
    def __init__(self, logger):
        self.logger = logger
        self.req = None         # ZMQ REQ socket for Discovery service
        self.sub = None         # ZMQ SUB socket for broker or direct publishers
        self.poller = None      # ZMQ poller for event loop
        self.addr = None
        self.port = None
        self.upcall_obj = None  # Handle to subscriber application
        self.handle_events = True
        self.connected_publishers = set()  # To prevent duplicate connections

    def configure(self, args):
        try:
            self.logger.info("SubscriberMW::configure")

            self.addr = args.addr
            self.port = args.port
            self.dissemination = args.dissemination  # Direct or Broker

            context = zmq.Context()
            self.poller = zmq.Poller()

            self.req = context.socket(zmq.REQ)
            self.sub = context.socket(zmq.SUB)

            self.poller.register(self.req, zmq.POLLIN)
            self.poller.register(self.sub, zmq.POLLIN)

            connect_str = f"tcp://{args.discovery}"
            self.req.connect(connect_str)

            self.logger.info("SubscriberMW::configure completed")
        except Exception as e:
            raise e

    def event_loop(self, timeout=None):
        try:
            self.logger.info("SubscriberMW::event_loop - Running event loop")
            while self.handle_events:
                events = dict(self.poller.poll(timeout=timeout))
                if not events:
                    timeout = self.upcall_obj.invoke_operation()
                elif self.req in events:
                    timeout = self.handle_reply()
                elif self.sub in events:
                    self.handle_incoming_data()
                else:
                    raise Exception("Unknown event after poll")
        except Exception as e:
            raise e

    def handle_reply(self):
        try:
            self.logger.info("SubscriberMW::handle_reply")
            bytesRcvd = self.req.recv()
            disc_resp = discovery_pb2.DiscoveryResp()
            disc_resp.ParseFromString(bytesRcvd)

            if disc_resp.msg_type == discovery_pb2.TYPE_REGISTER:
                timeout = self.upcall_obj.register_response(disc_resp.register_resp)
            elif disc_resp.msg_type == discovery_pb2.TYPE_ISREADY:
                timeout = self.upcall_obj.isready_response(disc_resp.isready_resp)
            elif disc_resp.msg_type == discovery_pb2.TYPE_LOOKUP_PUB_BY_TOPIC:
                timeout = self.upcall_obj.receiveDataByTopic(disc_resp.lookup_resp)
            else:
                raise ValueError("Unrecognized response message")
            return timeout
        except Exception as e:
            raise e

    def register(self, name, topiclist):
        try:
            self.logger.info("SubscriberMW::register")
            reg_info = discovery_pb2.RegistrantInfo()
            reg_info.id = name
            reg_info.addr = self.addr
            reg_info.port = self.port

            register_req = discovery_pb2.RegisterReq()
            register_req.role = discovery_pb2.ROLE_SUBSCRIBER
            register_req.info.CopyFrom(reg_info)
            register_req.topiclist[:] = topiclist

            disc_req = discovery_pb2.DiscoveryReq()
            disc_req.msg_type = discovery_pb2.TYPE_REGISTER
            disc_req.register_req.CopyFrom(register_req)

            buf2send = disc_req.SerializeToString()
            self.req.send(buf2send)
            self.logger.info("SubscriberMW::register - Sent registration request")
        except Exception as e:
            raise e

    def is_ready(self):
        try:
            self.logger.info("SubscriberMW::is_ready started")
            isready_req = discovery_pb2.IsReadyReq()
            disc_req = discovery_pb2.DiscoveryReq()
            disc_req.msg_type = discovery_pb2.TYPE_ISREADY
            disc_req.isready_req.CopyFrom(isready_req)
            buf2send = disc_req.SerializeToString()
            self.req.send(buf2send)
        except Exception as e:
            raise e

    def receiveDataTopic(self, topiclist):
        """Lookup publishers or broker based on dissemination strategy."""
        try:
            self.logger.info("SubscriberMW::receiveDataTopic")
            lookup_request = discovery_pb2.LookupPubByTopicReq()
            lookup_request.topiclist[:] = topiclist

            disc_req = discovery_pb2.DiscoveryReq()
            disc_req.msg_type = discovery_pb2.TYPE_LOOKUP_PUB_BY_TOPIC
            disc_req.lookup_req.CopyFrom(lookup_request)

            buf2send = disc_req.SerializeToString()
            self.req.send(buf2send)
        except Exception as e:
            raise e

    def connectPub(self, IP, port):
        """Connect to publisher or broker."""
        connect_str = f"tcp://{IP}:{port}"
        if connect_str not in self.connected_publishers:
            self.logger.debug(f"SubscriberMW::connectPub - Connecting to {connect_str}")
            self.sub.connect(connect_str)
            self.connected_publishers.add(connect_str)

        self.logger.info(f"Currently connected publishers: {self.connected_publishers}")

    def subscribe(self, topiclist):
        """Subscribe to topics from the broker or publisher."""
        try:
            self.logger.info("SubscriberMW::subscribe")
            for topic in topiclist:
                self.sub.setsockopt_string(zmq.SUBSCRIBE, topic)
        except Exception as e:
            raise e

    def handle_incoming_data(self):
        """Handle data received from publishers or broker."""
        try:
            data = self.sub.recv_string()
            topic, value = data.split(":", 1)
            self.logger.info(f"Received - {topic}: {value}")
        except Exception as e:
            raise e

    def set_upcall_handle(self, upcall_obj):
        self.upcall_obj = upcall_obj

    def disable_event_loop(self):
        self.handle_events = False

