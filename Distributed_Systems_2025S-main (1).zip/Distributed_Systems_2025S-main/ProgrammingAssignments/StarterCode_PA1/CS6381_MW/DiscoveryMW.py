###############################################
#
# Author: Aniruddha Gokhale
# Vanderbilt University
#
# Purpose: Discovery Middleware with Broker Support
#
# Created: Spring 2023
#
###############################################

import zmq
import time
import logging
from CS6381_MW import discovery_pb2


class DiscoveryMW:
    def __init__(self, logger):
        self.logger = logger
        self.rep = None      # ZMQ REP socket to handle incoming requests
        self.poller = None   # ZMQ Poller for non-blocking event handling
        self.addr = None
        self.port = None

    def configure(self, addr, port):
        """Configure the Discovery Middleware."""
        try:
            self.logger.info("DiscoveryMW::configure")

            # Save address and port
            self.addr = addr
            self.port = port

            # Create ZMQ context
            context = zmq.Context()

            # REP socket for handling requests
            self.rep = context.socket(zmq.REP)
            bind_str = f"tcp://{self.addr}:{self.port}"
            self.rep.bind(bind_str)

            # Poller for handling events
            self.poller = zmq.Poller()
            self.poller.register(self.rep, zmq.POLLIN)

            self.logger.info(f"DiscoveryMW::configured socket at {bind_str}")
        except Exception as e:
            self.logger.error(f"DiscoveryMW::configure - Exception: {e}")
            raise e

    def recv_request(self):
        """Receive requests from publishers, subscribers, and broker."""
        try:
            self.logger.debug("DiscoveryMW::recv_request - Waiting for request")

            # Poll with no timeout (blocking)
            events = dict(self.poller.poll())

            if self.rep in events and events[self.rep] == zmq.POLLIN:
                # Receive and parse the request
                bytes_rcvd = self.rep.recv()
                self.logger.debug(f"DiscoveryMW::recv_request - Received {len(bytes_rcvd)} bytes")

                # Deserialize the request using protobuf
                request = discovery_pb2.DiscoveryReq()
                request.ParseFromString(bytes_rcvd)

                return request
            else:
                return None
        except Exception as e:
            self.logger.error(f"DiscoveryMW::recv_request - Exception: {e}")
            raise e

    def send_response(self, response):
        """Send responses back to publishers, subscribers, or broker."""
        try:
            self.logger.debug(f"DiscoveryMW::send_response - Sending response: {response}")

            # Serialize the response
            buf2send = response.SerializeToString()

            # Send the serialized response
            self.rep.send(buf2send)
        except Exception as e:
            self.logger.error(f"DiscoveryMW::send_response - Exception: {e}")
            raise e

