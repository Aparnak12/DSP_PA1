###############################################
#
# Author: Aniruddha Gokhale
# Vanderbilt University
#
# Purpose: Middleware for Publisher with Broker-based dissemination
#
###############################################

import time
import logging
import zmq
from CS6381_MW import discovery_pb2


class PublisherMW:
    def __init__(self, logger):
        self.logger = logger
        self.req = None  # ZMQ REQ socket for Discovery service
        self.pub = None  # ZMQ PUB socket for dissemination via Broker
        self.poller = None  # ZMQ poller for event loop
        self.addr = None
        self.port = None
        self.upcall_obj = None  # Handle to PublisherAppln
        self.handle_events = True  # Event loop control
        self.broker_address = None  # Address of the Broker to publish to

    def configure(self, args):
        """Configure the publisher middleware."""
        try:
            self.logger.info("PublisherMW::configure")
            self.port = args.port
            self.addr = args.addr

            # Setup ZMQ context
            context = zmq.Context()
            self.poller = zmq.Poller()

            # REQ socket for Discovery Service
            self.req = context.socket(zmq.REQ)
            self.poller.register(self.req, zmq.POLLIN)

            connect_str = f"tcp://{args.discovery}"
            self.req.connect(connect_str)

            # PUB socket for sending data (bind later after getting broker info)
            self.pub = context.socket(zmq.PUB)

            self.logger.info("PublisherMW::configure completed")
        except Exception as e:
            raise e

    def event_loop(self, timeout=None):
        """Run the event loop to handle requests and responses."""
        try:
            self.logger.info("PublisherMW::event_loop - run the event loop")
            while self.handle_events:
                events = dict(self.poller.poll(timeout=timeout))
                if not events:
                    timeout = self.upcall_obj.invoke_operation()
                elif self.req in events:
                    timeout = self.handle_reply()
                else:
                    raise Exception("Unknown event after poll")
            self.logger.info("PublisherMW::event_loop - out of the event loop")
        except Exception as e:
            raise e

    def handle_reply(self):
        """Handle responses from Discovery Service."""
        try:
            self.logger.info("PublisherMW::handle_reply")
            bytes_received = self.req.recv()
            disc_resp = discovery_pb2.DiscoveryResp()
            disc_resp.ParseFromString(bytes_received)

            if disc_resp.msg_type == discovery_pb2.TYPE_REGISTER:
                timeout = self.upcall_obj.register_response(disc_resp.register_resp)
            elif disc_resp.msg_type == discovery_pb2.TYPE_ISREADY:
                timeout = self.upcall_obj.isready_response(disc_resp.isready_resp)
            elif disc_resp.msg_type == discovery_pb2.TYPE_LOOKUP_BROKER:
                timeout = self.handle_broker_lookup(disc_resp.lookup_broker_resp)
            else:
                raise ValueError("Unrecognized response message")
            return timeout
        except Exception as e:
            raise e

    def register(self, name, topiclist):
        """Register with the Discovery Service."""
        try:
            self.logger.info("PublisherMW::register")

            reg_info = discovery_pb2.RegistrantInfo()
            reg_info.id = name
            reg_info.addr = self.addr
            reg_info.port = self.port

            register_req = discovery_pb2.RegisterReq()
            register_req.role = discovery_pb2.ROLE_PUBLISHER
            register_req.info.CopyFrom(reg_info)
            register_req.topiclist[:] = topiclist

            disc_req = discovery_pb2.DiscoveryReq()
            disc_req.msg_type = discovery_pb2.TYPE_REGISTER
            disc_req.register_req.CopyFrom(register_req)

            buf2send = disc_req.SerializeToString()
            self.req.send(buf2send)

            self.logger.info("PublisherMW::register - Sent registration request")
        except Exception as e:
            raise e

    def is_ready(self):
        """Check if Discovery Service is ready."""
        try:
            self.logger.info("PublisherMW::is_ready started")
            isready_req = discovery_pb2.IsReadyReq()
            disc_req = discovery_pb2.DiscoveryReq()
            disc_req.msg_type = discovery_pb2.TYPE_ISREADY
            disc_req.isready_req.CopyFrom(isready_req)
            buf2send = disc_req.SerializeToString()
            self.req.send(buf2send)
        except Exception as e:
            raise e

    def lookup_broker(self):
        """Request broker information from Discovery Service."""
        try:
            self.logger.info("PublisherMW::lookup_broker started")
            lookup_request = discovery_pb2.LookupBrokerReq()
            disc_req = discovery_pb2.DiscoveryReq()
            disc_req.msg_type = discovery_pb2.TYPE_LOOKUP_BROKER
            disc_req.lookup_broker_req.CopyFrom(lookup_request)
            buf2send = disc_req.SerializeToString()
            self.req.send(buf2send)
        except Exception as e:
            raise e

    def handle_broker_lookup(self, lookup_resp):
        """Handle Broker lookup response."""
        try:
            self.logger.info("PublisherMW::handle_broker_lookup")

            if lookup_resp.status == discovery_pb2.STATUS_SUCCESS:
                self.broker_address = f"tcp://{lookup_resp.broker_info.addr}:{lookup_resp.broker_info.port}"
                self.logger.info(f"Connecting to Broker at {self.broker_address}")

                # Connect to the Broker PUB socket
                self.pub.connect(self.broker_address)

                # Move to the DISSEMINATE state
                self.upcall_obj.state = self.upcall_obj.State.DISSEMINATE
                return 0
            else:
                raise ValueError("No broker available or lookup failed")

        except Exception as e:
            self.logger.error(f"PublisherMW::handle_broker_lookup - Exception: {e}")
            raise e

    def disseminate(self, topic, data):
        """Send topic data to Broker."""
        try:
            self.logger.info(f"PublisherMW::disseminate - Sending {topic}: {data}")

            if not self.broker_address:
                raise RuntimeError("Broker address not set. Cannot disseminate data.")

            message = f"{topic}:{data}"
            self.pub.send_string(message)

            self.logger.info("PublisherMW::disseminate complete")
        except Exception as e:
            raise e

    def set_upcall_handle(self, upcall_obj):
        """Set upcall handle to communicate with PublisherAppln."""
        self.upcall_obj = upcall_obj

    def disable_event_loop(self):
        """Exit the event loop."""
        self.handle_events = False

