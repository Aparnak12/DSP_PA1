###############################################
#
# Author: Updated for Broker Fix
# Vanderbilt University
#
# Purpose: Broker Middleware with Discovery Integration
#
# Created: Spring 2023
#
###############################################

import zmq
from CS6381_MW import discovery_pb2


class BrokerMW:
    def __init__(self, logger):
        self.logger = logger
        self.req = None
        self.pub = None
        self.sub = None
        self.poller = None
        self.addr = None
        self.port = None
        self.upcall_obj = None
        self.connected_publishers = set()

    def configure(self, args):
        self.logger.info("BrokerMW::configure")

        self.addr = args.addr
        self.port = args.port

        context = zmq.Context()
        self.poller = zmq.Poller()

        self.req = context.socket(zmq.REQ)
        self.pub = context.socket(zmq.PUB)
        self.sub = context.socket(zmq.SUB)

        self.poller.register(self.req, zmq.POLLIN)
        self.poller.register(self.sub, zmq.POLLIN)

        self.req.connect(f"tcp://{args.discovery}")
        self.pub.bind(f"tcp://*:{self.port}")

        self.logger.info("BrokerMW::configure completed")

    def event_loop(self, timeout=None):
        self.logger.info("BrokerMW::event_loop")
        while True:
            events = dict(self.poller.poll(timeout=timeout))
            if not events:
                timeout = self.upcall_obj.invoke_operation()
            elif self.req in events:
                timeout = self.handle_reply()
            elif self.sub in events:
                self.forward_message()

    def register(self):
        self.logger.info("BrokerMW::register")

        reg_info = discovery_pb2.RegistrantInfo()
        reg_info.id = "broker"
        reg_info.addr = self.addr
        reg_info.port = self.port

        register_req = discovery_pb2.RegisterReq()
        register_req.role = discovery_pb2.ROLE_BROKER  # ✅ Correct role added
        register_req.info.CopyFrom(reg_info)

        disc_req = discovery_pb2.DiscoveryReq()
        disc_req.msg_type = discovery_pb2.TYPE_REGISTER
        disc_req.register_req.CopyFrom(register_req)

        self.req.send(disc_req.SerializeToString())

    def lookup_publishers(self):
        lookup_request = discovery_pb2.LookupPubByTopicReq()
        lookup_request.topiclist.append("*")  # Subscribe to all topics

        disc_req = discovery_pb2.DiscoveryReq()
        disc_req.msg_type = discovery_pb2.TYPE_LOOKUP_PUB_BY_TOPIC
        disc_req.lookup_req.CopyFrom(lookup_request)

        self.req.send(disc_req.SerializeToString())

    def connect_to_publishers(self, lookup_resp):
        for pub in lookup_resp.matched_pubs:
            connect_str = f"tcp://{pub.addr}:{pub.port}"
            if connect_str not in self.connected_publishers:
                self.sub.connect(connect_str)
                self.connected_publishers.add(connect_str)

    def forward_message(self):
        message = self.sub.recv_string()
        self.pub.send_string(message)
        self.logger.info(f"BrokerMW::forward_message - Forwarded message: {message}")

    def set_upcall_handle(self, upcall_obj):
        self.upcall_obj = upcall_obj

    def handle_reply(self):
        try:
            self.logger.info("BrokerMW::handle_reply")

            bytesRcvd = self.req.recv()

            disc_resp = discovery_pb2.DiscoveryResp()
            disc_resp.ParseFromString(bytesRcvd)

            self.logger.info(f"BrokerMW::handle_reply - Received msg_type: {disc_resp.msg_type}")

            if disc_resp.msg_type == discovery_pb2.TYPE_REGISTER:
                timeout = self.upcall_obj.register_response(disc_resp.register_resp)
            elif disc_resp.msg_type == discovery_pb2.TYPE_ISREADY:
                timeout = self.upcall_obj.isready_response(disc_resp.isready_resp)
            elif disc_resp.msg_type == discovery_pb2.TYPE_LOOKUP_PUB_BY_TOPIC:
                self.connect_to_publishers(disc_resp.lookup_resp)
                timeout = None  # No timeout needed after connecting
            else:
                raise ValueError("BrokerMW::handle_reply - Unrecognized response message")

            return timeout

        except Exception as e:
            self.logger.error(f"BrokerMW::handle_reply - Exception: {e}")
            raise e

